#include "so_stdio.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define MAX 4096

typedef struct _so_file
{
	int fd;//file descriptor
	unsigned char buffer[MAX];//buffer
	int length_buffer;//lungime buffer dupa un read
	char last_op[20];//ultima operatie facuta
	char file_name[100];//numele fisierului deschis
	char mode[5];//tipul
	int curr_index_buff;//indexul curent din buffer la care s-a ajuns
	int cursor;//cursorul curent
	char write;//drept de scriere
	char read;//drept de citire
	char append;//drept de append
	char open;//opened 1/closed 0
	char error;//eroare 1, non-eroare 0
	char eof;//eof 1, non-eof 0
	int pid;//pid
} SO_FILE;

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
	SO_FILE *so_file = (SO_FILE *)malloc(sizeof(SO_FILE));

	if (so_file == NULL)
		return so_file;
	//actualizeaza cu -1 pentru a putea fi ulterior modificat de open()
	so_file->fd = -1;

	so_file->write = 0;
	so_file->read = 0;
	so_file->append = 0;

	//deschide dupa modul primit ca parametru
	if (strcmp(mode, "r") == 0) {
		so_file->fd = open(pathname, O_RDONLY);
		so_file->read = 1;
	} else if (strcmp(mode, "r+") == 0) {
		so_file->fd = open(pathname, O_RDWR);
		so_file->read = 1;
		so_file->write = 1;
	} else if (strcmp(mode, "w") == 0) {
		so_file->fd = open(pathname, O_CREAT|O_TRUNC|O_WRONLY, 0640);
		so_file->write = 1;
	} else if (strcmp(mode, "w+") == 0) {
		so_file->fd = open(pathname, O_CREAT|O_TRUNC|O_RDWR, 0640);
		so_file->read = 1;
		so_file->write = 1;
	} else if (strcmp(mode, "a") == 0) {
		so_file->fd = open(pathname, O_CREAT|O_APPEND|O_WRONLY, 0640);
		so_file->append = 1;
		so_file->write = 1;
	} else if (strcmp(mode, "a+") == 0) {
		so_file->fd = open(pathname, O_CREAT|O_APPEND|O_RDWR, 0640);
		so_file->read = 1;
		so_file->write = 1;
		so_file->append = 1;
	}
	//daca nu am deschis fisierul returnam null
	if (so_file->fd < 0) {
		free(so_file);
		so_file = NULL;
		return so_file;
	}
	//actualizam datele din so_file
	strcpy(so_file->file_name, pathname);
	strcpy(so_file->mode, mode);
	strcpy(so_file->last_op, "");
	so_file->curr_index_buff = 0;
	so_file->cursor = 0;
	so_file->error = 0;
	so_file->open = 1;
	so_file->length_buffer = 0;
	so_file->eof = 0;

	return so_file;
}

int so_fclose(SO_FILE *stream)
{
	int res = 0;
	int error = 0;

	if (stream == NULL)
		return SO_EOF;
	//daca anterior am avut o operatie de write facem flush
	if (strcmp(stream->last_op, "write") == 0
		&& stream->curr_index_buff > 0) {
		res = so_fflush(stream);
		//daca am avut eroare in fflush returnam eroare
		if (res == SO_EOF) {
			free(stream);
			return SO_EOF;
		}

	}

	res = close(stream->fd);

	if (res < 0)
		error = SO_EOF;

	free(stream);

	if (error == SO_EOF)
		return error;

	return 0;
}

long so_ftell(SO_FILE *stream)
{
	if (stream == NULL)
		return -1;

	return stream->cursor;
}

int so_fflush(SO_FILE *stream)
{
	int res;
	int curr_index;

	curr_index = 0;
	//vom folosi un while pentru a permite sa se faca fflush
	//pe toate datele existente.E posibil ca un write sa nu scrie
	//cat ii dam noi ca parametru si de aceea facem astfel.
	while (stream->curr_index_buff > 0) {
		res = write(stream->fd, stream->buffer + curr_index,
		 stream->curr_index_buff);

		stream->curr_index_buff -= res;
		curr_index += res;
		//daca am avut eroare la write returnam eroare si actualizam
		//flagul de eroare
		if (res < 0) {
			stream->error = 2;
			stream->length_buffer = 0;
			stream->curr_index_buff = 0;
			return SO_EOF;
		}
	}

	//daca nu am avut nicio eroare de scriere invalidam bufferul
	stream->length_buffer = 0;
	stream->curr_index_buff = 0;
	stream->eof = 0;
	return 0;
}

int so_fseek(SO_FILE *stream, long offset, int whence)
{
	int res;

	if (stream == NULL)
		return -1;
	//daca ultima operatie a fost write facem fflush(care duce
	//si la actualizarea cursorului din fisier)
	if (strcmp(stream->last_op, "write") == 0) {
		res = so_fflush(stream);
		if (res == SO_EOF)
			return SO_EOF;
	}
	//daca ultima operatie a fost de read actualizam cursorul
	//invalidam bufferul.
	if (strcmp(stream->last_op, "read") == 0) {
		lseek(stream->fd, stream->curr_index_buff, SEEK_CUR);
		stream->length_buffer = 0;
		stream->curr_index_buff = 0;
	}
	//facem operatia de so_fseek ceruta
	res = lseek(stream->fd, offset, whence);

	if (res < 0)
		return -1;

	stream->cursor = res;

	return 0;
}

//citeste un block de dimensiune cel mult MAX din fisier
int so_read_bucket(SO_FILE *stream)
{
	ssize_t no;

	if (stream == NULL || stream->read == 0)
		return 0;

	no = read(stream->fd, stream->buffer, MAX);

	if (no <= 0) {
		stream->eof = 1;
		stream->error = 1;
		return SO_EOF;
	}

	lseek(stream->fd, -no, SEEK_CUR);
	stream->length_buffer = no;
	stream->curr_index_buff = 0;

	return 0;
}


int so_fgetc(SO_FILE *stream)
{
	int res;

	if (stream == NULL  || stream->read == 0)
		return SO_EOF;

	if (stream->open < 0)
		return SO_EOF;
	//daca ultima operatie a fost de write facem fflush la buffer
	if (strcmp(stream->last_op, "write") == 0) {
		res = so_fflush(stream);

		if (res == SO_EOF)
			return SO_EOF;
		//facem acest strcpy pentru a permite ulterior sa se intre
		//in urmatoarea bucla de if.
		strcpy(stream->last_op, "");
		res = so_read_bucket(stream);

		if (res == SO_EOF)
			return SO_EOF;
	}

	//daca ultima operatie a fost de read,write(dupa fflush de mai sus),
	//sau prima operatie executata.
	if (strcmp(stream->last_op, "read") == 0 ||
	 strcmp(stream->last_op, "") == 0) {
		if (stream->curr_index_buff == stream->length_buffer) {
			so_fseek(stream, 0, SEEK_CUR);
			res = so_read_bucket(stream);
			if (res == SO_EOF)
				return SO_EOF;
		}
			stream->cursor++;
			stream->curr_index_buff++;
			strcpy(stream->last_op, "read");
			res = stream->buffer[stream->curr_index_buff-1];
			return (int)((unsigned char)res);
	}

	return 0;
}

int so_fputc(int c, SO_FILE *stream)
{
	int res = 0;

	if (stream == NULL || stream->write == 0)
		return SO_EOF;

	if (stream->open < 0)
		return SO_EOF;
	//daca ultima operatie a fost de read apelam fseek care reseteaza
	//cursorul la pozitia curenta
	if (strcmp(stream->last_op, "read") == 0) {
		res = so_fseek(stream, 0, SEEK_CUR);

		if (res == -1)
			return SO_EOF;
		strcpy(stream->last_op, "");
	}
	//daca ultima operatie a fost write verificam daca s-a prelucrat
	//tot ce era in buffer.Daca da se face fflush ,altfel se scrie
	//in buffer.
	if (strcmp(stream->last_op, "write") == 0 ||
	 strcmp(stream->last_op, "") == 0) {
		stream->buffer[stream->curr_index_buff] = (unsigned char)c;
		stream->cursor++;
		stream->curr_index_buff++;
		strcpy(stream->last_op, "write");

		if (stream->curr_index_buff == MAX) {
			res = so_fflush(stream);
			if (res == SO_EOF) {
				stream->error = 1;
				return SO_EOF;
			}
		}
	}
	//daca s-a ajuns aici sigur am scris ceva,deci nu am ajuns la EOF
	stream->eof = 0;
	return c;
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	size_t no_bytes = size*nmemb;
	int i, c = 0;
	unsigned char *p = (unsigned char *)ptr;
	//daca nu avem ce citi
	if (size <= 0 || nmemb <= 0)
		return 0;

	if (ptr == NULL)
		return 0;

	if (stream == NULL || stream->read == 0)
		return 0;
	//apelam so_fgetc pentru no_bytes
	for (i = 0; i < no_bytes; i++) {
		c = so_fgetc(stream);
		if (c == SO_EOF) {
			stream->eof = 1;
			return i;
		}
		*p = (unsigned char)c;
		p++;
	}

	return nmemb;
}

size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
	int i, res;
	unsigned char c = 0;
	unsigned char *p = (unsigned char *)ptr;

	res = 0;
	//daca nu avem ce scrie
	if (size <= 0 || nmemb <= 0)
		return 0;

	if (ptr == NULL)
		return 0;

	if (stream == NULL || stream->write == 0)
		return 0;
	//apelam so_fputc de size*nmemb ori
	for (i = 0; i < size * nmemb; i++) {
		c = *p;
		res = so_fputc(c, stream);
		if (res == SO_EOF) {
			//stream->error = 1;
			return 0;
		}
		stream->eof = 0;
		p++;
	}

	return nmemb;
}

int so_fileno(SO_FILE *stream)
{
	if (stream == NULL)
		return -1;

	return stream->fd;
}

int so_feof(SO_FILE *stream)
{
	if (stream == NULL)
		return -1;

	return stream->eof;
}

int so_ferror(SO_FILE *stream)
{
	if (stream == NULL)
		return -1;

	return stream->error;
}

SO_FILE *so_popen(const char *command, const char *type)
{
	int i;
	int filedes[2];
	int pid;
	int ok;
	int res;
	//creem un pipe.filedes[0] - read, filedes[1] - write
	res = pipe(filedes);

	//daca pipe-ul a esuat intoarcem NULL
	if (res == -1)
		return NULL;

	pid = fork();
	switch (pid) {
		//cazul de eroare
	case -1:
		for (i = 0; i < 2; i++)
			close(filedes[i]);
		return NULL;
		//copil
	case 0:
		if (strcmp(type, "r") == 0)
			ok = dup2(filedes[1], STDOUT_FILENO);
		if (strcmp(type, "w") == 0)
			ok = dup2(filedes[0], STDIN_FILENO);
		//daca dup2 a esuat returneaza null
		if (ok == -1)
			return NULL;
		//inchide filedes[0],filedes[1]
		for (i = 0; i < 2; i++)
			if (close(filedes[i]) == -1)
				return NULL;
		//executa comanda cu execl
		execl("/bin/sh", "sh", "-c", command, NULL);

		return NULL;

		//parinte
	default:
		if (strcmp(type, "r") == 0)//inchide write nefolosit
			if (close(filedes[1]) == -1)//daca am avut eroare
				return NULL;

		if (strcmp(type, "w") == 0)//inchide read nefolosit
			if (close(filedes[0]) == -1)//daca am avut eroare
				return NULL;

		//cream un nou SO_FILE si actualizam info
		SO_FILE *so_file = malloc(sizeof(SO_FILE));

		if (strcmp(type, "r") == 0)
			so_file->fd = filedes[0];
		if (strcmp(type, "w") == 0)
			so_file->fd = filedes[1];

		strcpy(so_file->file_name, "");
		strcpy(so_file->mode, "");
		strcpy(so_file->last_op, "");
		so_file->curr_index_buff = 0;
		so_file->cursor = 0;
		so_file->error = 0;
		so_file->open = 1;
		so_file->length_buffer = 0;
		so_file->eof = 0;
		so_file->pid = pid;
		so_file->read = 1;
		so_file->write = 1;
		so_file->append = 1;
		return so_file;
	}

	return NULL;
}

int so_pclose(SO_FILE *stream)
{
	int pid;
	int status;
	int res;

	if (stream == NULL)
		return SO_EOF;

	pid = stream->pid;
	//inchides stream-ul dat ca parametru
	res = so_fclose(stream);

	if (res == SO_EOF)
		return SO_EOF;
	//asteptam pidul din stream
	//merge si daca punem waitpid(-1,&status,0) pentru
	//a astepta toti copii.
	waitpid(pid, &status, 0);
	//returnam statusul
	return status;

}

